import logo from './logo.svg';
import './App.css';
import Routers from './routers/routers';
import Main from './components/main';
import CounterState from './components/counter';

function App() {
  return (
    <div>
      <Routers/>
      {/* <Main/> */}
      {/* Hi */}
      <CounterState/>
    </div>
  );
}

export default App;
