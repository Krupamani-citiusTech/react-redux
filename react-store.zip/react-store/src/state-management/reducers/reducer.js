import appState from "../appState";
import * as actions from '../actions/actions'
const userReducer = (state=appState,action) => {
if(action.type === actions.GETUSERDATA){
    return {
        ...state,
        userData:action.payload
    }
} 
if(action.type === actions.ADDUSERDATA){
    console.log(action.payload)
    return {
        ...state,
        userData:action.payload
    }
}
return state
}
export default userReducer