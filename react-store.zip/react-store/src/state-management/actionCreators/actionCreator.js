import { dataServices } from "../../services"
import * as actions from '../actions/actions'
export function getActionCreator(id){
    return (dispatch) => {

        dataServices.getData(id).then((res)=>{
    
            console.log('res from creator',res)
    
            dispatch({type:actions.GETUSERDATA,payload:res.data})
    
        })
}
}
