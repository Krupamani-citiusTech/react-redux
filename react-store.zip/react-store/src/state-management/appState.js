const appState = {
    userData : {}
}
export default appState;