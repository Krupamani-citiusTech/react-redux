import GetStatus from "../components/getStatus"
import GetTitle from "../components/getTitle";
import Main from "../components/main";
import URLS from "../urls";
import { Route, Routes } from 'react-router';
import PostDataVal from "../components/postData";
import GetUserData from "../components/getUserData";

const Routers = () => {
    return(
            <Routes>
                <Route path={URLS.main} element={<Main/>}/>
                <Route path={URLS.title + '/:id'} element={<GetTitle/>}/>
                <Route path={URLS.status + '/:id'} element={<GetStatus/>}/>
                <Route path={URLS.userData} element={<PostDataVal/>}/>
                <Route path={URLS.data} element={<GetUserData/>}/>
            </Routes>
    )
}
export default Routers;