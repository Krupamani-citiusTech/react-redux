import { useSelector } from "react-redux"

const GetUserData = () => {
    const getUser = useSelector((state)=>state.userReducer.userData.data)
return(
    <div>
       {getUser}
    </div>
)
}
export default GetUserData
