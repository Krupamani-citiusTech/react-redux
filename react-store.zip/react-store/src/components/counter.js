import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import * as actions from '../store/actions/counter_action'
const CounterState = () => {
    const [counter,setCounter] = useState(0);
    const dispatch = useDispatch();
    const selector = useSelector(state=>state.counter.counter)
    useEffect(()=>{
    setCounter(selector)
    },[selector])
    const Increment = (e)=> {
        e.preventDefault();
        console.log('increment:')
      dispatch({type:actions.INCREMENT,payload:counter})
    }
    const Decrement = ()=> {
        dispatch({type:actions.DECREMENT,payload:counter})
      }
return(
    <div>
        {console.log('selector',selector)}
        <button onClick={Increment}>Increment</button>
        <button onClick={Decrement}>Decrement</button>
    </div>
)
}
export default CounterState