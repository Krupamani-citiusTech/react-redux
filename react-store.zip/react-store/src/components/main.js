import { useRef } from "react"
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import URLS from "../urls";
import * as actions from '../state-management/actionCreators/actionCreator'

const Main = () => { 
    const navigate = useNavigate();
    const inputVal = useRef(0);
    const dispatch = useDispatch()
    const handleTitle = () => {
        console.log(inputVal.current.value)
        navigate(URLS.title+'/'+inputVal.current.value)
        dispatch(actions.getActionCreator(inputVal.current.value))

    }
    const handleStatus = () => {
        console.log(inputVal.current.value)
        navigate(URLS.status + '/' + inputVal.current.value)
    }

    return(
        <div>
            <input type = "number" ref={inputVal}/>
            <button onClick={handleTitle}>Get Title</button>
            <button onClick={handleStatus}>Get Status</button>
        </div>
    )
}
export default Main;