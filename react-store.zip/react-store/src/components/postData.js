import { useEffect } from "react"
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import { Link } from "react-router-dom"
import * as actions from '../state-management/actions/actions'
const PostDataVal = ()=>{
    const dispatch = useDispatch();
    const navigate = useNavigate()
    useEffect(()=>{
     
    },[])
    const handleClick = (e)=> {
   e.preventDefault();
//    dispatch(actioncreators.postActionCreator({data:'Post call'}))
dispatch({type:actions.ADDUSERDATA,payload:{data:'Post call'}})
navigate('/data')
    }
    return(
        <div>POST
            <button onClick={handleClick}>Add</button>
            {/* <Link to='/data'>data</Link> */}
        </div>
    )
}
export default PostDataVal;