const GetStatus = () => {
    return(
        <div>Get Status</div>
    )
}
export default GetStatus;