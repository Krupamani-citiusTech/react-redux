import { useSelector } from "react-redux";
const GetTitle = () => {
    const getData = useSelector((state) => state.userReducer.userData)
    console.log('getData: ',getData)
    return(
        <div>Get Title
            {getData.title}
        </div>
    )
}
export default GetTitle;