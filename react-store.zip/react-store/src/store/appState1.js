const appState1 = {
    counter:0
}
export default appState1;