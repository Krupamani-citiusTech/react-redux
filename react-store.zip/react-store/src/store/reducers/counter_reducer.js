import appState1 from "../appState1";
import * as actions from '../actions/counter_action';
function FuncReducer(state=appState1,action){
if(action.type === actions.INCREMENT){
    console.log('action.payload',action.payload)
    return {
        ...state,
        counter:action.payload+1
    }
}
if(action.type === actions.DECREMENT){
    return {
        ...state,
        counter:action.payload-1
    }
}
return state
}
export default FuncReducer;