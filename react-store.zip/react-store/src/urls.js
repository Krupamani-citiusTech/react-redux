const URLS = {
    main:'/',
    title : '/title',
    status : '/status',
    userData:'/userdata',
    data:'/data'
}
export default URLS;