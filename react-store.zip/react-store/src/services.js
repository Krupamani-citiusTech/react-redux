import axios from "axios";
class DataService{
    getData(id){
        const url = 'https://jsonplaceholder.typicode.com/todos';
        return axios.get(`${url}/${id}`)
    }
    postData(data){
        console.log('data:',data)
        const url = "http://localhost:3000/user/"
        return axios.post(`${url}`,data)
    } 
}
const dataServices = new DataService();
export {dataServices}