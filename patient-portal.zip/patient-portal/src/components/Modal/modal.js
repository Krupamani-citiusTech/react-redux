// import React from 'react';

// const Modal = props => {
//     const {} = props;
//     return(
//         <Dialog
//         open={open}
//         aria-labelledby="responsive-dialog-title">
//             <DialogTitle id="responsive-dialog-title">
//                 {modalTitle}
//                 <CancelIcon className="closeModal" onClick={() => { handleClose(); reset() }} />
//             </DialogTitle>
//             <DialogContent>
//                 <DialogContentText>
//                     {modalData}
//                 </DialogContentText>
//             </DialogContent>
//     </Dialog>
//     )
// };


// export default Modal;