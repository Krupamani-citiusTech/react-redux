const ViewModal=()=>{
    return(
        <>
        view working</>
    )
}
export default ViewModal;