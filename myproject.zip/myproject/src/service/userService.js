import axios from 'axios';
import * as urls from '../urls'

class UserService{
getAllUsers(){
    let url = urls.USERS_API+'/allusers';
    return axios.get(url)
}
addUser(user){
    let url = urls.USERS_API+'/adduser';
    let config = {
        headers : {
            'Content-Type':'application/json'
        }
    }
    console.log('user from service',user)
    return axios.post(url,user,config) 
}
startswith(startswith){
    console.log('startswith',startswith)
    let url = urls.USERS_API+'/users/'+ startswith
    return axios.get(url)
}
deleteUser(delUser){
    console.log('delUser',delUser)
    let url = urls.USERS_API+'/deleteuser/'+ delUser
    return axios.delete(url)
}
}
let userService = new UserService()
export {userService}
// export default new UserService()