import React from "react";
import instance from "../urls";

class Apicalls extends React.Component{

     getUsers = () =>{
        return instance.get('/users')
    }
}
export default new Apicalls()