

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter } from 'react-router-dom';
import appState from './state-management/app-state';
import {applyMiddleware, combineReducers,createStore} from 'redux';
import {Provider} from 'react-redux'
import { counterReducer } from './state-management/reducers/counterreducer';
import thunk from 'redux-thunk';
import { UserReducer } from './state-management/reducers/userReducer';
import authReducer from './state-management/reducers/authReducer';
import axios from 'axios';

//for combining the reducers
const rootReducer = combineReducers({
  cr : counterReducer,
  users : UserReducer,
  authRed : authReducer  
}
)
//creating store with root reducer
// let appStore = createStore(counterReducer)

//apply the thunk middleware to the redux flow
 let appStore = createStore(rootReducer,applyMiddleware(thunk))
 //GET
axios.interceptors.request.use(req=>{
  req.headers['test'] = 'Bearer ' + 'some authkey';
  return req
},err=>{
  return Promise.reject(err);
})
//POST
axios.interceptors.response.use(res=>{
  console.log('coming to POST index:')
  res.headers['postStatus'] = 'Posted Successfully'
  if(res.status=='201'){
    console.log('coming to if')
    return 'Posted Successfully'
  } 
},err=>{
  return Promise.reject(err);
})
ReactDOM.render(
  <React.StrictMode>
    {/* Make the store avalilable to the Root Component and all its children */}
    <Provider store={appStore}>
    <App />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
