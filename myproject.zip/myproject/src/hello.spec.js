describe("Test SUIT",()=>{
test.only('Third test case',()=>{
expect(10).toEqual(10) //assersion
})
})
it.skip('First Test case',()=>{
    expect(10).toEqual(100)
})
it('Second Test case',()=>{
    
})