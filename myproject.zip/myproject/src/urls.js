import axios from 'axios';

const instance = axios.create({
    baseURL: "http://localhost:3001/"
});

export default instance;
//https://karthikeyan-webapi.azurewebsites.net/swagger/index.html
export const USERS_API = 'https://karthikeyan-webapi.azurewebsites.net/api/Users';

