import {useState} from 'react';
const ProgressBarDemo = () => {
    const [val,setVal] = useState(0)
    const setValuer = (e) => {
        setVal(e.target.value)
    }

  
    return (
      <>
        <div className="App">
          {console.log('Progress Val',val)}
          <h1>Progress bar</h1>
          {/* <ProgressBar width={val} /> */}
          <progress value ={val} max = "100"/>
          <form>
            <label for="html">Input Percentage:</label>
            <input type="number" id="val" onChange={setValuer} />
          </form>
        </div>
      </>
    );
  }
  export default ProgressBarDemo;