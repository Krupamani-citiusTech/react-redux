import {useRef, useState} from 'react'
const FormData = () => {
    const nameVal = useRef('');
    const priceVal = useRef(null)
    const [arrOfObj,setArrOfObj] = useState([])
    // const handleChange = e => {
    //     const { id, value } = e.target;
    //     setArrOfObj(prevState => ({
    //         ...prevState,
    //         [id]: value
    //     }));
    // };
    const handleSubmit = (e) => {
        e.preventDefault();
        // console.log('nameVal:',nameVal.current.value,'priceVal:',priceVal.current.value)
        // let arrOfObj = [];
        // myArr.push(arrOfObj);
        // // setArrOfObj([...myArr])
        // // arrOfObj.push({name:this.state.inputVal})
        // setArrOfObj({...myArr})
        // console.log('arrOfObj:',arrOfObj)
        // arrOfObj.push({name:nameVal.current.value,price:priceVal.current.value})
        setArrOfObj(result => [...result, {name:nameVal.current.value,price:priceVal.current.value}])
       

    }
    const handleCancel = (remData) => {
       
        let removeVals = arrOfObj.filter(val=>val.name!==remData.name && val.price !== remData.price)
        console.log('after remove Data:',removeVals)
        setArrOfObj(removeVals)
    }
return(
    <div>
        { console.log('arrOfObj:',arrOfObj)}
        <form onSubmit={handleSubmit}>
            <input type="text" id="name" ref={nameVal}/>
            <input type="number" id="price" ref={priceVal}/>
            <button>Submit</button>
        </form>
        {arrOfObj.map((val,inx)=>(
            <>
            <li key={inx}>{val.name}, {val.price} <button onClick={()=>handleCancel(val)}>cancel</button></li>
            </>
        ))}
    </div>
)
}
export default FormData