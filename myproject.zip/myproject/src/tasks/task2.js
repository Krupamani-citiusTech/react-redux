import React from "react";
class Like_Dislike extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            likes : 100,
            disLikes:25,
            hasLiked: false,
            hasDisliked: false,
        }
    }
    handleLike = () => {
        if(!this.state.hasDisliked) {
          this.setState({
            hasLiked: !this.state.hasLiked
          });
        }else {
          this.setState({
            hasLiked: true,
            hasDisliked: false
          });
        }
      }
     
       handleDislike = () => {
        if(!this.state.hasLiked) {
          this.setState({
            hasDisliked: !this.state.hasDisliked
          });
        }else {
          this.setState({
            hasLiked: false,
            hasDisliked: true
          });
        }
      }
      
    render(){
        const { hasDisliked, hasLiked } = this.state;
        const classLikeButton = `like-button ${hasLiked ? 'liked': ''}`;
        const classDisLikeButton = `dislike-button ${hasDisliked ? 'disliked': ''}`;
        return( 
            <div>
                <button className="like_button" onClick = {this.handleLike}>Like | 
                <span className={classLikeButton}>{this.state.likes+1}</span>
                </button>
                <button className="dislike_button">Dislike | 
                <span className={classDisLikeButton}>{this.state.disLikes-1}</span>
                </button>
               
            </div>
        )
    }
}
export default Like_Dislike