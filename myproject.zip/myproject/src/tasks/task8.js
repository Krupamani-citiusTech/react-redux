import { useState } from "react"


const CitiesCountriesPract = () => {
    const [countriesCities,setcountriesCities] = useState([
        {
            country: 'India',
            cities:['Hyderabad','Mumbai','Banglore']
        },
        {
            country:'US',
            cities:['London','Liverpool','Leeds']
        },
        {
            country:'UK',
            cities:['New yark','Chicago','Portland']
        },
       
    ])
    const [inputVal,setInputVal] = useState('')
    const [country,selectedCnty] = useState('');
    const [citiesVal,setCities] = useState([])
    const selectedCountryfun = (e) => {
         selectedCnty(e.target.value)
         countriesCities.map(countryVals=>{
             if(countryVals.country == e.target.value){
                 setCities(countryVals.cities)
             }
         })
    }
    const handleChange = (e)=>{
        setInputVal(e.target.value)
    }
    const handleSubmit = (e) => {
      e.preventDefault()
    setcountriesCities(result=>[...result,{country:inputVal}])
    }
return(
    <div>
        <h3>Cities and Countries</h3>
        <span>Countries:</span>
        <select onChange={selectedCountryfun}>
            <option>Select Country</option>
            {countriesCities.map((val,index)=>(
               <option key={index}>{val.country}</option>
            ))}
        </select>
        <span>Cities</span>
            <select>
                <option>select city</option>
            {citiesVal.map((city,inx)=>(
                <option key={inx}>{city}</option>
            ))}
            </select>
            <br/>
            <form onSubmit={handleSubmit}>
                <input type='text' placeholder='Add cities' value={inputVal} onChange={handleChange}/>
                <button>Add</button>
            </form>
    </div>
)
}
export default CitiesCountriesPract;