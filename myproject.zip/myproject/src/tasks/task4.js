import { useState } from "react";

const ShowHide = () => {
    const [data,setData] = useState(false);
    const hideData = () => {
        setData(!data)
    }

    return (
        <div>
          <button onClick={hideData}>Hide/Show</button>
          {!data && <h1>Welcome to react challenges</h1>}
        </div>
    )
}
export default ShowHide;