import { useState,useEffect } from "react";

const Timer = () =>  {
  const [time, setTime] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(true);
  
  useEffect(()=>{
      setTimeout(()=>{
      if(isActive && isPaused){
      setTime(time=>time+1)
      }
    },1000)
  })

  const startTimer = () => {
    // Complete this function
    console.log('coming to start timer')
    setIsActive(true)
    setIsPaused(true)
    console.log('time',time)
  };
  const stopTimer = () => {
    // Complete this function
    setIsPaused(false)
  };
  const resetTimer = () => {
    // Complete this function
    setIsActive(false)
    setIsPaused(false)
    setTime(0)
    
  };
  return (
    <div className="container">
      <h1>Timer</h1>
      <span> 0 mins </span>
      <span> {time} secs</span>
      <div>
        <button onClick={startTimer}>Start</button>
        <button onClick={stopTimer}>Stop</button>
        <button onClick={resetTimer}>Reset</button>
      </div>
    </div>
  );
}
export default Timer;