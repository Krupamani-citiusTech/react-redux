import { useState } from "react"

const TwoWayDataBinding = () => {
    const [data,setData] = useState('');
    const handleChange = (e) =>{
        setData(e.target.value)
    }
    return(
        <div>{console.log('data:',data)}
            <h1>Two Way Data Binding</h1>
            <input type="text" id="val" onChange={handleChange}/>
            <span>{data}</span>
        </div>
    )
}
export default TwoWayDataBinding;