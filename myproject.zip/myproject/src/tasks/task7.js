import {useRef, useState} from 'react';

const BooklistPract = () => {
    const [book,setBooks]=useState(['book1','book2','book3']);
    const inputRef = useRef('');
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('inputRef: ',inputRef.current.value)
        setBooks(result => [...result,inputRef.current.value])

    }

return(
    <div>
        <h1>Controlled book list component</h1>
        <ol>
        {book.map((val,inx)=>(
            <li key={inx}>{val}</li>
        ))}
          </ol>
          <form onSubmit={handleSubmit}>
          <input type="text" placeholder="enterbook" ref={inputRef}/>
          <button>Add</button>
          </form>
    </div>
)
} 
export default BooklistPract