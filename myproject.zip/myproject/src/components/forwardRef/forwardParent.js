import { useRef } from "react";
import ForwardChild from "./forwardChild";

const ForwardParent = ()=>{
    const inputRef = useRef('')
    const handleClick = ()=>{
        console.log('coming to handle click')
    inputRef.current.value = '1000';
    inputRef.current.focus();
    }

    return(
        <div>
            <ForwardChild ref={inputRef}/>
            <button onClick={handleClick}>Add input value</button>
        </div>
    )
}
export default ForwardParent;