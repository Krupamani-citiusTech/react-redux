import { forwardRef } from "react";


const ForwardChild = (props,ref)=>{
    // const [inputVal,setInputVal] = useState('')
    return(
        <div>
            <input type="text" ref={ref}/>
        </div>
    )
}
export default ForwardChild;