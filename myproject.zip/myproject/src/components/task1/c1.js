import React, { useState } from "react";

const C1_component = (props)=>{
    const [inputVal,setInputVal] = useState('');
   const handleChange = (e)=>{
       setInputVal(e.target.value)
    //    console.log('event',inputVal)
   }
    const handleSubmit = (e)=>{
    // console.log(e.target.value)
    console.log('event',inputVal)
    props.C1ToApp(inputVal)
    e.preventDefault();
    }
    return(
        <div>
       from C1:
        <form onSubmit={handleSubmit}>
        <input type="text" value={inputVal} onChange={handleChange}/>
        <button>send</button>
        </form>
        </div>
        
    )
}
export default C1_component;