const C2_component = (props)=>{
    return(
        <div>from C2: {props.appToC2}</div>
    )
}
export default C2_component;