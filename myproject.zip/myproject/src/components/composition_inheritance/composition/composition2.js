
import Composition1 from "./composition1";

const Composition2 = () => {
    return(
        <div>
            <Composition1/>
            <button>Create</button>
        </div>
    )
}
export default Composition2;