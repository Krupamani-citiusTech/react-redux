const Composition1 = () => {
    return(
        <div>
            <input type="text"/>
        </div>
    )
}
export default Composition1;