import Composition1 from "./composition1";


const Composition3 = () => {
    return(
        <div>
            <Composition1/>
            <button>Update</button>
        </div>
    )
}
export default Composition3;