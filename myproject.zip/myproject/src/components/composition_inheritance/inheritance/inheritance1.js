import React from "react";

class Inheritance1 extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            value:10
        }
    }
   
    render(){
        return(
            <div>
                state val :{this.state.value}
                <input type="text"/>
            </div>
        )
    }
}
export default Inheritance1;