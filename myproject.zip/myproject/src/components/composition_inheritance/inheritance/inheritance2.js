import Inheritance1 from "./inheritance1";

class Inheritance2 extends Inheritance1{
    constructor(props){
        super(props)
    }
    render(){
        const inheri1 = super.render()
        return(
            <div>
               {inheri1}
               <button>Create-H</button>{console.log('value: ',super.state)}
            </div>
        )
    }
}
export default Inheritance2