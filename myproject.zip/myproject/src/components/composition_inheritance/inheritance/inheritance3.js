import Inheritance1 from "./inheritance1";

class Inheritance3 extends Inheritance1{
    constructor(props){
        super(props)
    }
    render(){
        const inheri2 = super.render()
        return(
            <div>
               {inheri2}
               <button>Update-H</button>
            </div>
        )
    }
}
export default Inheritance3