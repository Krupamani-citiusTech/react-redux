import React from "react";
import Child from "./child";

class Parent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            data:'Data from parent component',
            value:''
        }
    }
    fromChild = (fromChildVal) =>{
    console.log('fromChild',fromChildVal)
    this.setState({value:fromChildVal})
    }
    render(){
        console.log('this.state--->',this.state)
        return(
            <div>
                <h1>Parent-{this.state.value}</h1>
                <Child parentToChild = {this.state.data} childToParent={this.fromChild}/>
            </div>
        )
    }
}
export default Parent;