import React from "react";

class Child extends React.Component{
    constructor(props){
        super(props);
        console.log('data: ',props)
        this.state = {
          value: this.props.parentToChild 
        }
    }
    handleSubmit = (event)=>{
    console.log('submit-->',event.target.name.value)
    this.props.childToParent(event.target.name.value)
    event.preventDefault();
    }
    render(){
        return(
            <div>
                <h1>Child-{this.state.value}</h1>
                <form onSubmit={this.handleSubmit}>
                    <input type="text" name ='name' placeholder = 'Enter text'/>
                    <button>Submit</button>
                </form>
            </div>
        )
    }
}
export default Child;