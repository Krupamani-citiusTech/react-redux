import React, { Component } from 'react'

class ErrorBoundary extends Component{
    constructor(props){
        super(props)

        this.state = {
            throwsError: false
        }
    }

    static getDerivedStateFromError(error){
        console.log('error from getDerivedStateFromError',error)
        return {
            throwsError: true
        }
    }

    componentDidCatch(error, info){
        console.log('error---->',error);
        console.log(info);
    }

    render(){
        console.log('from render',this.state.throwsError,this.props.children)
        if(this.state.throwsError){
            return (
                <h1>Oops! An error occurred</h1>
            )
        }

        return this.props.children;
    }
}

export default ErrorBoundary