import React from 'react'


const Demo = (props)=>{
    if(props.theme === "white"){
        throw new Error("An error occurred....");
    }

    return (
        <section>
            <h1>This is a {props.theme} text</h1>
        </section>
    )

}

export default Demo;