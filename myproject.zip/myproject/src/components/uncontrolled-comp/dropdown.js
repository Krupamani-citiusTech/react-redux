import React from "react";

class Dropdown extends React.Component{
    constructor(props){
    super(props);
    this.selectVal = React.createRef();
    this.inputVal = React.createRef();
    this.state = {
    countries : [
        {
            name:'India',
            cities:['Mumbai','Hyderabad','Kakinada']
        },
        {
            name: "US",
            cities: ['London','Liverpool','Leeds']
          },
          {
            name: "UK",
            cities: ['New york','Chicago','Portland']
          }, 
    ],
    selectedCountry : '',
    cities:[]
    }
    }
    handleChange = ()=>{
        this.setState({selectedCountry:this.selectVal.current.value})
        let cities = this.state.countries.find(country=>country.name===this.selectVal.current.value).cities
        this.setState({cities:cities})
        console.log('cities---->',this.state.cities)
    }
    handleSubmit = (e)=>{
        this.state.countries.push({name:this.inputVal.current.value})
        this.setState({...this.state.countries})
        e.preventDefault()
    }
    render(){
        // console.log('selectVal --->',this.selectVal?.current?.value)
        return(
            <div>
            <div><h2>Uncontrolled Component</h2></div>
            Countries : &nbsp;
            <select ref={this.selectVal} onChange={this.handleChange}>
                {this.state.countries.map((countries,index)=>{
                  return <option key={index}>{countries.name}</option>
                })
            }
            </select>
            {/* {this.state.selectedCountry} */}
            Cities : &nbsp; 
            <select>
            {this.state.cities?.map((cities,inx)=>{
                return <option key={inx}>{cities}</option>
            })}
            </select>
            <br/>
                <br/>
                <br/>
            <div>
                <form onSubmit = {this.handleSubmit}>
                <input type='text' ref={this.inputVal}/>
                <button>Add</button>
                </form>
            </div>
            </div>
        )
    }
}

export default Dropdown;