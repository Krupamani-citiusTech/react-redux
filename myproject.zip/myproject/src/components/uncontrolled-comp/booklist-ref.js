import React from "react";

class BookList_ref extends React.Component{
    constructor(props){
        super(props);
        this.inputVal = React.createRef();
        this.state = {
            booksList:['book1','book2','book3']
        }
    }
    
    handleSubmit = (e)=>{
    console.log('from handle click: ',this.inputVal.current.value);
    console.log('this.state: ',this.state)
    const {booksList} = this.state;
    booksList.push(this.inputVal.current.value);
    this.setState(booksList)
    e.preventDefault();
    }
    render(){
        return(
            <div>
                <h1>Uncontrolled BookList Component</h1>
                <ol>
                    {this.state.booksList.map((vals,index)=>{
                        return <li key={index}>{vals}</li>
                    })}
                </ol>
                <form onSubmit = {this.handleSubmit}>
                <input type='text' placeholder='enter book name' ref={this.inputVal}/>
                <button>Add</button>
                </form>
            </div>
        )
    }
}
export default BookList_ref;