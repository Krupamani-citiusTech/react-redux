import React from "react";
class UserInfo extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        console.log('this.props from userInfo')
        return(
            <div>
             Info of user with id:{this.props.match.params.id}
             {JSON.stringify(this.props.match)}
            </div>
        )
    }
}
export default UserInfo;