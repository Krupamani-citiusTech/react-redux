import React from "react";
import { Link } from "react-router-dom";
class NavigationBar extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div>
                <Link to='/home'>Home</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/about'>About</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/booklist'>Booklist</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/likes'>Likes</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/componentCom'>Component communication</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/searchuser/100'>Searchuser</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/lifecycle_methods'>lifecycle_methods</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/userlist'>UserList</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/userdetails'>Userdetails</Link>
                &nbsp;&nbsp;&nbsp;
                <Link to='/aaa'>Invalid_route</Link>
            </div>
        )
    }
}
export default NavigationBar;