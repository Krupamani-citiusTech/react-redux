import React from "react";
class Invalid_route extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <div>
                <p>404 - Page not found</p>
            </div>
        )
    }
}
export default Invalid_route;