import React from "react";
class About extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        
        return(
            // setTimeout(()=>{
            <div>About Component</div>
        // },3000)
        )
  
    }
}
export default About;