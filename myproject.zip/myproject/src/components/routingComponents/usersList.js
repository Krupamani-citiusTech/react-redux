import React from "react";
import { BrowserRouter, Route, Switch,Link } from "react-router-dom";
import UserInfo from "./userInfo";
class UserList extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        console.log('this.props.match.path',this.props)
        let userlist = ['user1','user2','user3'];

        return(
            <div>
                UserList Component 
                {userlist.map((user,index)=>{
                    return <React.Fragment>
                        <Link to={`${this.props.match.path}/userInfo/${user}`}><p key={index}>{user}</p></Link>
                        &nbsp;&nbsp;&nbsp;
                    </React.Fragment>
                })}
                <BrowserRouter>
                <Switch>
                    <Route path='/userlist/userInfo/:id' component={UserInfo}/>
                </Switch>
                </BrowserRouter>
            </div>
        )
    }
}
export default UserList;