import React from "react";
class SearchUser extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <div>
               {/* {JSON.stringify(this.props.match)} */}
               <span>search user with Id: {this.props.match.params.id}</span>
            </div>
        )
    }
}
export default SearchUser;