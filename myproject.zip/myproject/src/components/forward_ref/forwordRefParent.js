import {useRef} from 'react';
import ForwardRefChild from './forwardRefChild';
const ForwardParent = ()=>{
    const inputVal = useRef('');
    const handleClick = (e) => {
    e.preventDefault();
    console.log('inputVal: ',inputVal.current.value)
    }
    return(
    <div>
     <ForwardRefChild ref={inputVal}/>
     <button onClick={handleClick}>Add input Val</button>
    </div>
    )
}
export default ForwardParent;