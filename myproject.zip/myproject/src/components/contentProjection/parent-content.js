import React from "react";
import Child_content from "./child-content";
class Parent_content extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        return(
            <div>
            <Child_content>
                <input type='text'/>
            </Child_content>
            </div>
        )
    }
}
export default Parent_content