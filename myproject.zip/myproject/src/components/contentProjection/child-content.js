import react from "react";
import React from "react";

class Child_content extends React.Component{
constructor(props){
    super(props);
}
shouldComponentUpdate(nextProps) {
    if (nextProps.value !== this.props.value) {
      return true;
    } else {
      return false;
    }
  }
render(){
    console.log('coming to child1')
    return(
        <react.Fragment>
        <div>Child {this.props.children}
        <br/>
        {this.props.greet}
        </div>
    
        </react.Fragment>

    )
}
}
export default Child_content;