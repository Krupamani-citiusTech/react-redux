import { useState, useEffect } from "react";
import axios from 'axios';
const InterceptorComp = () => {
    useEffect(()=>{
    axios.get('https://jsonplaceholder.typicode.com/todos/1').then(req=>{
        return req
    })
    axios.post('https://jsonplaceholder.typicode.com/posts',JSON.stringify({title:'test'})).then(res=>{
       console.log('res: ',res)
    })
    },[])
    return(
        <div>Interceptor</div>
    )
}
export default InterceptorComp;
