import * as React from 'react';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

export default function Mui_Dropdown() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button
        id="basic-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
      >
        Dashboard
      </Button>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
      >
        <MenuItem onClick={handleClose}>Profile</MenuItem>
        <MenuItem onClick={handleClose}>My account</MenuItem>
        <MenuItem onClick={handleClose}>Logout</MenuItem>
      </Menu>
    </div>
  );
}


// import React from 'react';
// import AsyncSelect from 'react-select/async';
// import { components } from 'react-select';

// const LimitedChipsContainer = ({ children, hasValue, ...props }) => {
//   if (!hasValue) {
//     return (
//       <components.ValueContainer {...props}>
//         {children}
//       </components.ValueContainer>
//     );
//   }

//   const CHIPS_LIMIT = 2;
//   const [chips, otherChildren] = children;
//   const overflowCounter = chips.slice(CHIPS_LIMIT).length;
//   const displayChips = chips.slice(overflowCounter, overflowCounter + CHIPS_LIMIT);

//   return (
//     <components.ValueContainer {...props}>
//       {displayChips}

//       {overflowCounter > 0 && `+ ${overflowCounter}`}

//       {otherChildren}
//     </components.ValueContainer>
//   );
// };

// export default ({ loadOptions, placeholder, ...selectSearchProps }) => (
//   <AsyncSelect
//     className="select-search"
//     classNamePrefix="select-search"
//     placeholder={placeholder}
//     loadOptions={loadOptions}
//     hideSelectedOptions={false}
//     isMulti
//     components={{ ValueContainer: LimitedChipsContainer }}
//     {...selectSearchProps}
//   />
// );