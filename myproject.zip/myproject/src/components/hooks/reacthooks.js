import React, { useEffect, useRef, useState } from 'react';

const ReactHooks = (props) => {
    const [value,setVal] = useState(0);
    const inputVal = useRef(0);
    const [useRefVal,setUseRefVal] = useState('');
    /**No dependency passed: useEffect(() => { //Runs on every render});
     * An empty array: useEffect(() => {//Runs only on the first render}, []);
     * useEffect(() => {//Runs on the first render & any time any dependency value changes}, [prop, state]);
     */
    useEffect(()=>{
        setVal(value)
    },[value]);
    const handleClick = (e) => {
        e.preventDefault();
        console.log('inputVal',inputVal.current.value)
        setUseRefVal(inputVal.current.value)
    }
    return (
        <div>useState :  {value} (change the state value using useEffect)
        <br/>
        useRef : <input type="text" ref = {inputVal} />
        <button onClick={handleClick}>Send</button>
        useRef-value : {useRefVal}
        <button onclick={()=>setVal(value=>value+1)}>increment{value}</button>
        </div>
    )
}
export default ReactHooks;