import { useState } from "react";

const Controlled = () => {
     const [inputVals,setInputVals] = useState({
         firstName : '',
         lastName : ''
     })
     const [errors,setErrors] = useState({})
     const handleChange = (e) => {
         setInputVals((prev)=>({
             ...prev,
            [e.target.id] : e.target.value
         }))
    }
    const handleValidation = () => {
        const {firstName,lastName} = inputVals;
        let errors = {}
        let formValid = true;
        if(!firstName){
            errors['firstName'] = "First name required";
             formValid = false;
        }
        if(!lastName){
            errors['lastName'] = "Last name required";
            formValid = false;

        }
        setErrors(errors)
        return formValid
    }
     const handleClick = (e) => {
        if (handleValidation()) {
         
        } 
        e.preventDefault();
        console.log('firstName: ',inputVals.firstName,'lastName: ',inputVals.lastName)
     }
     
    
return(
    <div>
        <label>First Name</label>
        <input type="text" value={inputVals.firstName} id="firstName"
        error={errors["firstName"] ? true : false}
        helperText={errors["firstName"] ? errors["firstName"] : ''}
         onChange={handleChange}/>

        <label>Last Name</label>
        <input type="text" value = {inputVals.lastName} id="lastName" 
        error={errors["lastName"] ? true : false}
        helperText={errors["lastName"] ? errors["lastName"] : ''}
        onChange={handleChange}/>

        <button onClick={handleClick}>Submit</button>
    </div>
)
}
export default Controlled;