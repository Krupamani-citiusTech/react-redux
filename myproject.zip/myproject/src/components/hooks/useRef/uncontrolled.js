import { useRef } from "react"

const Uncontrolled = ()=>{
    const inputRef = useRef({
        firstName:'',
        lastName:''
    })
    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log('inputRef: ',inputRef.current.firstName.value)
    }
    return(
        <div>
            <label>First Name</label>
            <input type="text" ref={(ele)=>inputRef.current.firstName=ele}/>
            <label>Last Name</label>
            <input type="text" ref={(ele)=>inputRef.current.lastName=ele}/>
            <button onClick={handleSubmit}>Submit</button>
        </div>
    )
}
export default Uncontrolled