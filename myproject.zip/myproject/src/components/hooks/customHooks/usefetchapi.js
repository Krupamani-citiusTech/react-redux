import { useEffect, useState } from "react"
import UseFecthapi from "./fetchapi";



const UseFetchApi = () => {
    const data = UseFecthapi(`https://jsonplaceholder.typicode.com/todos/1`)   
    return(
        <div>
            {console.log('coming from custom hook',data)}
            <h3>Custome hook</h3> {data.title}
        </div>
    )
}
export default UseFetchApi;