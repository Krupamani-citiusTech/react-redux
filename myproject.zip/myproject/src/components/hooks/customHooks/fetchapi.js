import { useState } from "react";
import { useEffect } from "react";

const UseFecthapi = (url) => {
const [value,setValue] = useState([])
    useEffect(()=>{
    fetch(url).then(res=>res.json()).then(data=>setValue(data))
    },[url]);

    return value
}
export default UseFecthapi;