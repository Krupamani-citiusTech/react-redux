import React, { createContext, useState } from 'react';
import Comp2 from './comp2';
import Comp4 from './comp4';
export const UserContext = createContext();
const Comp1 = ()=>{
    const [user,setUser] = useState('CitiusTech');
  
    return(
        <div>
            <UserContext.Provider value={user}>
            Hello! {user} 
            <hr/>
            Component1
            <Comp2/>
            </UserContext.Provider>
        </div>
    )
}
export default Comp1;