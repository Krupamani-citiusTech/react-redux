import React, { useContext } from 'react';
import {UserContext} from './comp1';

const Comp4 = ()=>{
    // const user = useContext(UserContext);
    return(
        <div>
            Component4 !
            <UserContext.Consumer>
            {value=><span>{value}</span>}
            </UserContext.Consumer>
        </div>
    )
}
export default Comp4;