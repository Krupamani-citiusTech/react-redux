import React from 'react';
import Comp4 from './comp4';

const Comp3 = ()=>{
   
    return(
        <div>
            Component3 
            <Comp4/> 
        </div>
    )
}
export default Comp3;