import React, { useContext } from 'react';
import Comp3 from './comp3';
import { UserContext } from './comp1';

const Comp2 = ()=>{
    const user = useContext(UserContext);
    return(
        <div>
            Component2 {user}
            <Comp3/>
        </div>
    )
}
export default Comp2;