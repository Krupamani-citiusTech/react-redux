
import { useState,useCallback} from "react";
import Todos from "./todos";

const UseCallbackHook = () => {
    const [count, setCount] = useState(0);
    const [todos, setTodos] = useState([]);
  
    const increment = () => {
      setCount((c) => c + 1);
    };
    const addTodo = useCallback(() => {
        console.log('coming to todos');
      setTodos((t) => [...t, "New Todo"]);
    },[todos]);
  
    return (
      <>
      
        <Todos todos={todos} addTodo={addTodo} />
        <hr />
        <div>
          Count: {count}
          <button onClick={increment}>+</button>
        </div>
      </>
    );
}
export default UseCallbackHook;