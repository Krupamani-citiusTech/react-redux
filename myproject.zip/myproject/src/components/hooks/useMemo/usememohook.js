import { useMemo, useState, useEffect } from "react";

const UseMemoHook = () => {
const [counter,setCounter] = useState(0);
const [number,setNumber] = useState(5);
// const factorial = fact(number);
const factorial = useMemo(()=>
    fact(number),
    [number])
// const factorial = useEffect(()=>{
//     fact(number)
// },[number])
return(
    <div>
        <div>useMemo Hook</div>
        
        <button onClick={()=>setCounter(counter+1)}>cCounter Increment</button><br/>
        counter : {counter}<br/>
        factorial value : {factorial}
        <button onClick={()=>setNumber(number+1)}>fact Number Increment</button>
    </div>
)
}
const fact = (n)=>{
    let answer = 1;
    for(let i=n;i>=1;i--){
        answer = answer * i;
    }
    console.log('coming to factorial function')
    return answer;
}
export default UseMemoHook;