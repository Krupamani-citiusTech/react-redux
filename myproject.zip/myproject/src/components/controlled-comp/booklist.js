import React from 'react';
// const bookname = ['book1','book2','book3'];
class Booklist extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            booksList:['book1','book2','book3'],
            inputVal:''
        };
    }
    inputHandler = (event)=>{
    console.log('input: ',event.target.value)
    this.setState({inputVal:event.target.value})
    }
    handleClick = ()=>{
    console.log('newBook: ',this.state)
    let {booksList,inputVal} = this.state;
    booksList.push(inputVal);
    this.setState(booksList)
 
    }
    render(){
        console.log('booklist:render ',this.props)
        return(
            <div>
                {console.log('return: ',this.state.booksList)}
                <h1>Controlled BookList Component</h1>
                 <ol> 
                  {this.state.booksList.map((books,index)=>{
                   return <li key={index}>{books}</li>
                 })}
                </ol>
                    <input type='text' placeholder='enter book' value={this.inputVal} onChange={this.inputHandler}/>
                    <button onClick={this.handleClick}>Add</button>
                </div>
          
        )
    }
    
}
export default Booklist;