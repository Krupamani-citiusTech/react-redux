import React from 'react'
const FuncBooklist = () => {
    const [booksList,setBookList] = React.useState(['book1','book2','book3']);
       const inputVal = React.createRef();
       const handleSubmit = (e)=>{
        e.preventDefault();
        console.log('val:: ',inputVal.current.value)
        booksList.push(inputVal.current.value)
        console.log('addBook:',booksList)
        setBookList([...booksList])
  }

        return(
            <div>
                <h1>Uncontrolled BookList Component</h1>
                <ol>
                    {booksList.map((vals,index)=>{
                        return <li key={index}>{vals}</li>
                    })}
                </ol>
                <form onSubmit = {handleSubmit}>
                <input type='text' placeholder='enter book name' ref={inputVal}/>
                <button>Add</button>
                </form>
            </div>
        )

}
export default FuncBooklist;