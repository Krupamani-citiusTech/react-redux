import React from "react";
class CountriesCities extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            countries: [
            {
                  name: "India",
                  cities: ['Hyderabad','Mumbai','Bangulure']
                },
                {
                  name: "US",
                  cities: ['London','Liverpool','Leeds']
                },
                {
                  name: "UK",
                  cities: ['New york','Chicago','Portland']
                }, 
              ],
            selectedCountry:'',
            inputVal:'',
            cities:[]
        }
    }
    getSelectedCountry = (e)=>{
    this.setState({selectedCountry:e.target.value});
    let cities = this.state.countries.find(val=>val.name === e.target.value).cities;
    this.setState({cities:cities})
    e.preventDefault();
    }
    inputHandler = (e) =>{
      this.setState({inputVal:e.target.value})
      
    }
    handleSubmit = (e)=>{
      console.log('inputVal',this.state.inputVal)
      this.state.countries.push({name:this.state.inputVal})
      this.setState({...this.state.countries})
      e.preventDefault();
    }
    render(){
        //  console.log('cities',(this.state.cities),Object.keys(this.state.cities),Object.values(this.state.cities))
        console.log('cities',this.state.countries);
        return(
            <div> <div><h2>Controlled component</h2></div>
             Countries :  <select value = {this.state.selectedCountry} onChange={this.getSelectedCountry}>
                <option>Select</option>
                    {this.state.countries.map((values,index)=>{
                    console.log('values:: countries: ',values.name)
                    return <option key={index}>{values.name}</option>
                 })}
                    
                </select>
              &nbsp;Cities : <select>
                    <option>Select Country</option>
                {this.state.cities.map((val,index)=>{
                   return <option key={index}>{val}</option>
               })}
                </select>
                <br/>
                <br/>
                <br/>
                <form onSubmit={this.handleSubmit}>
                  <input placeholder='add countries' type='text' value = {this.state.inputVal} onChange={this.inputHandler}/>
                  <button>Add</button>
                </form>

            </div>
        )
    }
}

export default CountriesCities;