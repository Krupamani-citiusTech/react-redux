const B = () => {
    return(
        <div>B component</div>
    )
}
export default B;