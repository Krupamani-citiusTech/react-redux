import A from './A';
import B from './B';
import { useState } from 'react';
const Emnummethod = () => {
    const [value,setValue] = useState('A')
    let ENUM_STATES = {
        'A' : <A/>,
        'B' : <B/>,
        default:null
    }
    return(
        <div>
         {ENUM_STATES[value]}
        </div>
    )
}
export default Emnummethod;