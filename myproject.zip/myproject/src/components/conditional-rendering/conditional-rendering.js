import React from 'react';

const Conditional_render = () =>{
    const [value,setValue] = React.useState('false');
    return(
        <div>{value === 'true' ?<div>TRUE</div>:<div>FALSE</div>}</div>
    )
}
export default Conditional_render;