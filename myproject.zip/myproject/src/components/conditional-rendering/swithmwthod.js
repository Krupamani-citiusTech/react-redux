import {useState} from 'react'
import A from './A';
import B from './B';
const SwitchMethod = () => {
    const [value,setValue] = useState('B');
    const swithfunc = (choice) => {
        console.log('choice: ',choice)
    switch(choice){
        case 'A' : return <A/>
        case 'B' : return <B/>
        default : return null;
    }
    }
    return(
        <div>
        {swithfunc(value)}
        </div>
    )
}
export default SwitchMethod