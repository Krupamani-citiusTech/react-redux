
const A = () => {
    return(
        <div>A component</div>
    )
}
export default A;