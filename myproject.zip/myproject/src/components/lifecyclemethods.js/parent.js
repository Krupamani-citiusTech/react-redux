import React from 'react';
import Lifecycle_Child from './child';

class Lifecycle_Parent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            data : ''
        }
    }
    componentWillMount(){
        this.setState({
            data : 'Data from Parent'
        })
    }
    render(){
        return(
            <div>{console.log('data-lifecycle',this.state.data)}
            <Lifecycle_Child parentToChild = {this.state.data}/>
              </div>
        )
    }
}
export default Lifecycle_Parent;