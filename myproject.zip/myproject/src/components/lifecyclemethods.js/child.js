import React from 'react';
class Lifecycle_Child extends React.Component{
    /*The constructor method is called before the component is mounted to the DOM.
    you would initialize state and bind event handlers methods within the constructor method*/
    constructor(props){
        super(props);
        this.state = {
            valFromParent : '',
            value:0
        }
    }
    /*By returning an object, we update the state of the component before it is even rendered.
    it is called before render method*/

    static getDerivedStateFromProps(props,state){
     return {
        valFromParent : props.parentToChild
     }
    }
    /*It will call after render method
    It is for api calls and subscriptions */ 

    componentDidMount(){
    //   return {
    //     valFromParent : this.props.parentToChild
    //  }  
    this.setState({
        value : 10
    })
    }
    
    /** stores the previous values of the state after the DOM is updated. 
     * It will call before componentDidUpdate() and must return val
     */
    getSnapshotBeforeUpdate(prevprops,prevstate){
        
        if (this.state.value > prevstate.value) {
            console.log('State from getSnapshotBeforeUpdate',prevstate.value)
          }
          return null;
    }
    //useed to prevent rerendering of the component based on some condition.
    shouldComponentUpdate(nextProps) {
        if (nextProps.value !== this.props.value) {
          return true;
        } else {
          return false;
        }
      }
    //called immediately before react updates the DOM.
      componentWillUpdate(nextProps,nextState){
       
      }

    /** it will check snapshot val and It will call after render method*/
    componentDidUpdate(prevprops, prevstate, snapshot) {
     console.log('state from componentDidUpdate',this.state.value)  
      }

    /** It return the JSX element and do not attempt to use setState or 
     * interact with the external APIs.
     */
    render(){
        return(
            <div>
                {this.state.valFromParent} : 
                {this.state.value}
            </div>
        )
    }
}
export default Lifecycle_Child;