import React, { useState } from "react";
import Child1_component from "./child1";
import Child2_component from "./child2";
  
const Parent_compnent = () => {
  
// Using useState hooks for defining state
  const [counter1, setCounter1] = useState(0);
  
  const increase1 = () => {
    setCounter1(counter1 + 1);
  };
  const [counter2, setCounter2] = useState(0);
  
  const increase2 = () => {
    setCounter2(counter2 + 1);
  };
    
  return (
    <div className="container">
      <div>
        <Child1_component value={counter1} onClick={increase1} />
      </div>
      <div>
        <Child2_component value={counter2} onClick={increase2} />
      </div>
    </div>
  );
};
  
export default Parent_compnent;