import React from "react";
import { Button, Grid, TextField} from "@material-ui/core";
import { Link } from "react-router-dom";
import './signup.css';
import instance from "../urls";
import { connect } from "react-redux";
import { AUTH_TOKEN } from "../state-management/actions/authAction";
class Signup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            firstname:'',
            lastname:'',
            email:'',
            password:'',
            phoneNo:'',
            // authToken:''
        }
    }
    inputHandler = (event)=>{
        const { id, value } = event.target;
        this.setState(prevState => ({
            ...prevState,
            [id]: value
        }));
    }
    handleSubmit = (e)=>{
    e.preventDefault()
   console.log('this.state--->',this.state)
 const { email,firstname,lastname,password,phoneNo } = this.state;
instance.post('/register', {
            firstname: firstname, 
            lastname: lastname, 
            email: email, 
            phoneNo: phoneNo, 
            password: password, 
        }) 
    //     .then(res => {
    //         console.log('from signup:',res.data.accessToken);

    //         this.setState({
    //             authToken : res.data.accessToken
    //         })
    //  this.props.authDispatch(this.state.authToken)
    // // console.log('token:',this.state.authToken)
    //     })
    
    }
    render() {
        return (
            <div>
                <center>
                <form className="main-container" onSubmit={this.handleSubmit}>
                <Grid container spacing={1}>
                    <Grid item xs={12} md={6}>
                                <TextField fullWidth
                                    variant="outlined"
                                    label="Firstname"
                                    placeholder="Enter firstname"
                                    type="text"
                                    value={this.state.firstname} id="firstname" onChange={this.inputHandler}
                                />
                            </Grid> 
                    <Grid item xs={12} md={6}>
                    <TextField  fullWidth
                                    variant="outlined"
                                    label="Lastname"
                                    placeholder="Enter lastname"
                                    type="text"
                                    value={this.state.lastname} id="lastname" onChange={this.inputHandler}
                                />
                    </Grid> 
                    <Grid item xs={12} md={12}>
                    <TextField  fullWidth
                                    variant="outlined"
                                    label="Email"
                                    placeholder="Enter Email"
                                    type="email"
                                    value={this.state.email} id="email" onChange={this.inputHandler}
                                />
                    </Grid>
                    <Grid item xs={12} md={12}>
                    <TextField  fullWidth
                                    variant="outlined"
                                    label="Password"
                                    placeholder="Enter password"
                                    type="password"
                                    value={this.state.password} id="password" onChange={this.inputHandler}
                                />
                    </Grid>
                    <Grid item xs={12} md={12}>
                    <TextField  fullWidth
                                    variant="outlined"
                                    label="PhoneNo"
                                    placeholder="Enter phoneNo"
                                    type="text"
                                    value={this.state.phoneNo} id="phoneNo" onChange={this.inputHandler}
                                />
                    </Grid>
                    
                    <Grid item xs={12} md={12}>
                    <Button className="signin-btn" variant="contained" type="submit" color="secondary">Register</Button>
                    </Grid>  
                    <Grid item xs={12} md={12}>
                    <div>Already have an account? <Link to="/login">Login</Link></div>
                    </Grid>         
                </Grid>
                </form>
                </center>

            </div>
        )
    }
}

export default Signup;