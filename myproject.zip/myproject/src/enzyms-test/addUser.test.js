import {shallow,mount} from 'enzyme';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import AddUser from '../state-management/components/addUser';
const mockStore = configureStore([]);

describe('Should test the users',()=>{
let store;
let jsx;
beforeEach(()=>{
    store = mockStore({users:{users:[]}});
    jsx = <Provider store={store}>
        <AddUser/>
    </Provider>
})
it('test should mount',()=>{
    const wrapper = mount(jsx);
    console.log(wrapper.debug())
})
it('should test the user data',()=>{
    const wrapper = mount(jsx);
    const paras = wrapper.find('p')
    expect(paras.length).toBe(2)
})
it('should find the userData',()=>{
    const wrapper = mount(jsx);
    let userData = wrapper.find('AddUser').props().allUsers;
    })
it('should find the submit button',()=>{
    const wrapper = mount(jsx);
    let buttons = wrapper.find('button')
    buttons.forEach((b)=>{
        console.log('forEach',b.text())
    if(b.text()==='ADD THIS USER'){
        // b.simulate('click')
        // const expectedPayload = {type:'ADDUSERS'};
    //    expect(store.getActions()[0]).toEqual(expectedPayload)
    console.log('coming to if')
    }
    })
})
})