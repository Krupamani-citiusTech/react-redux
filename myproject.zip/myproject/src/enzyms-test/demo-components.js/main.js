import React from 'react';
import Child1 from './child1';
import Child2 from './child2';
import Child3 from './child3';
const Main = ()=>{
    return(
        <div>
            <p>Main Component</p>
            <Child1/>
            <Child2/>
            <Child3/>
            <div>
                <p>div element in Main Component</p>
            </div>
        </div>
    )
}
export default Main;