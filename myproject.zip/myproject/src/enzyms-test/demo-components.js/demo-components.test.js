import { mount,shallow } from "enzyme"
import Main from "./main"


describe('Shallow and mount testing',()=>{
// it('shollow',()=>{
//     const wrapper = shallow(<Main/>)
//     console.log(wrapper.debug())
// })
it('shollow',()=>{
    const wrapper = mount(<Main/>)
    console.log(wrapper.debug())
})
})