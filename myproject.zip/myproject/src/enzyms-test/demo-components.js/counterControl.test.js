
import { shallow,mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import CounterControl from '../../state-management/components/counterControl';
const mockStore = configureStore([]);
describe("CounterControl component",()=>{
    let store;
    let jsx;
    beforeEach(()=>{
        store = mockStore({cr:{counter:0}});
        jsx = <Provider store={store}>
            <CounterControl/>
        </Provider>
    })
  test('should render 2 buttons',()=>{
    //   const wrapper = shallow(jsx)
      const wrapper = mount(jsx)
    //   const wrapper = mount(<CounterControl/>);
      console.log(wrapper.debug())
      const buttons = wrapper.find('button')
    //   buttons.forEach = ((b)=>{
    //   console.log(b.text()) --->enzym API's
    //   })
      expect(buttons.length).toEqual(2)
  })
  test('should contain 1 p tag',()=>{
    const wrapper = mount(jsx)
      const paragraph = wrapper.find('p')
      expect(paragraph.length).toEqual(1)
  })
  test('should test the counter value of 0',()=>{
    const wrapper = mount(jsx)
    console.log('props--->',wrapper.find('CounterControl').props().counterVal)
    let counter = wrapper.find('CounterControl').props().counterVal;
    expect(counter).toEqual(0)
  })
  test('should dispatch correct action when increment is clicked',()=>{
    const wrapper = mount(jsx);
    let buttons = wrapper.find('button')
    buttons.forEach((b)=>{
    if(b.text() === 'Increment'){
      b.simulate('click')
      console.log('control',store.getActions()[0])
      const expectedPayload = {type:'INCREMENT'};
       expect(store.getActions()[0]).toEqual(expectedPayload)
    }
    });
  });
})

