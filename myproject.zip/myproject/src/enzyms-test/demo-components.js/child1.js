import React from "react";
const Child1 = ()=>{
    return(
    <div>
        <div>
            <p>Child1 Component</p>
        </div>
    </div>
    )
}
export default Child1;