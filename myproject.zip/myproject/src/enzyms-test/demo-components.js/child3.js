import React from "react";
const Child3 = ()=>{
    return(
    <div>
        <div>
            <p>Child3 Component</p>
        </div>
    </div>
    )
}
export default Child3;