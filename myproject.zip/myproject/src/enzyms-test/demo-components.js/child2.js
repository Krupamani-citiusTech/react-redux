import React from "react";
const Child2 = ()=>{
    return(
    <div>
        <div>
            <p>Child2 Component</p>
        </div>
    </div>
    )
}
export default Child2;