import {mount} from 'enzyme';
import CounterControl from '../../state-management/components/counterControl';
import CounterResult from '../../state-management/components/counterResult';
import {Provider} from 'react-redux'
import {createStore,combineReducers} from 'redux'
import { counterReducer } from '../../state-management/reducers/counterreducer'

describe('counterControl and counterResult tests',()=>{
    let store;
    let jsx;
    let rootReducer;
    beforeEach(()=>{
        rootReducer = combineReducers({
            cr : counterReducer
        });
        store = createStore(rootReducer)
        jsx = <Provider store = {store}>
            <CounterControl/>
            <CounterResult/>
        </Provider>
    })
    test('should increment counter in the store',()=>{
        const wrapper = mount(jsx);
        //get the increment using this text
        const incrementButton = wrapper.find('button[children="Increment"]')
        //click the button
        incrementButton.simulate('click')
        incrementButton.simulate('click')
        console.log(store.getState())
        //get the counter value from the store
        let counter = store.getState().cr.counter
        //assert
        expect(counter).toBe(2)
      
        })
        test('should display the current counter value',()=>{
            const wrapper = mount(jsx);
            //get the increment using this text
            const incrementButton = wrapper.find('button[children="Increment"]')
            //click the button
        incrementButton.simulate('click')
              // get the html element which displays the counter value
        let resultarea = wrapper.find("#result").text()
        expect(resultarea).toEqual("1")
        })
})