import { mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import CounterResult from '../../state-management/components/counterResult';
const mockStore = configureStore([]);
describe("CounterControl component",()=>{
    let store;
    let jsx;
    beforeEach(()=>{
        store = mockStore({cr:{counter:10}});
        jsx = <Provider store={store}>
            <CounterResult/>
        </Provider>
    })
  test('h4 should dispaly correct intial value of the counter',()=>{
      const wrapper = mount(jsx)
      let resultarea = wrapper.find("#result").text()
      expect(resultarea).toEqual("10")

  })
})

