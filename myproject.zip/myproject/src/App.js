import logo from './logo.svg';
import './App.css';
import Booklist from './components/controlled-comp/booklist';
import BookList_ref from './components/uncontrolled-comp/booklist-ref';
import Parent from './components/comp-communication/parent';
import CountriesCities from './components/controlled-comp/countriesCties';
import EnhancedLikes from './components/HOC/likesCount';
import EnhancedComments from './components/HOC/commentsCount';
import Login from './login/login';
import { BrowserRouter, Route, Switch} from "react-router-dom";
import Signup from './signup/signup';
import Home from './components/routingComponents/home';
import Invalid_route from './components/routingComponents/Invalid_route';
import NavigationBar from './components/routingComponents/navigationBar';
import UserList from './components/routingComponents/usersList';
import UserInfo from './components/routingComponents/userInfo';
import Apicalls from './service/apicalls';
import React, { useEffect, useState } from 'react';
import About from './components/routingComponents/about';
import UserDetails from './userdetails/userdetails';
import Parent_content from './components/contentProjection/parent-content';
import { Routes } from 'react-router';
import C1_component from './components/task1/c1';
import C2_component from './components/task1/c2';
import Dropdown from './components/uncontrolled-comp/dropdown';
import ConterControl from './state-management/components/counterControl';
import BasicMenu from './components/dropdown-mui';
import AllUsers from './state-management/components/allUsers';
import { ADDUSERS } from './state-management/actions/counteraction';
import AddUser from './state-management/components/addUser';
import SearchUser from './state-management/components/searchUser';
import DeleteUser from './state-management/components/deleteUser';
import FunctBooklist from './components/controlled-comp/funcBooklist';
import FuncBooklist from './components/controlled-comp/funcBooklist';
import Conditional_render from './components/conditional-rendering/conditional-rendering';
import Mui_Select from './components/dropdown-mui';
import Mui_Dropdown from './components/dropdown-mui';
import MultipleSelect from './components/dopdown-component.js/mui-dropdown';
import CounterResult from './state-management/components/counterResult';
import Task1 from './tasks/task1';
import Like_Dislike from './tasks/task2';

import UseErrorBoundary from './components/errorBoundary/useErrorBoundary';
import ReactHooks from './components/hooks/reacthooks';
import Lifecycle_Parent from './components/lifecyclemethods.js/parent';
import Comp1 from './components/hooks/contexthook/comp1';

import ReactForms from './components/reactForms';
import UseReducerHook from './components/hooks/useReducerHook/useReducerHook';
import UseMemoHook from './components/hooks/useMemo/usememohook';
import FormData from './tasks/task3';
import ShowHide from './tasks/task4';
import Timer from './tasks/task5';
import ProgressBarDemo from './tasks/task6';
import TwoWayDataBinding from './tasks/two-way-dataBinding';
import BooklistPract from './tasks/task7';
import CitiesCountriesPract from './tasks/task8';
import Composition2 from './components/composition_inheritance/composition/composition2';
import Composition3 from './components/composition_inheritance/composition/composition3';
import Inheritance2 from './components/composition_inheritance/inheritance/inheritance2';
import Inheritance3 from './components/composition_inheritance/inheritance/inheritance3';
import Controlled from './components/hooks/useRef/controlled';
import Uncontrolled from './components/hooks/useRef/uncontrolled';
import InterceptorComp from './components/interceptor/interceptorComp';
import ForwardParent from './components/forward_ref/forwordRefParent';
import SwitchMethod from './components/conditional-rendering/swithmwthod';
import Emnummethod from './components/conditional-rendering/Enummethod';


const AboutComponent = React.lazy(()=>import('./components/routingComponents/about'))
function App(props) {
  const [userData,setUserData] = useState([]);
  const [C1Data,setC1Data] = useState([])
  // useEffect(()=>{
  //   Apicalls.getUsers().then((responce=>{
  //     console.log('responce from app:',responce.data)
  //   })
  // },[]);
//   useEffect(() => {
//     Apicalls.getUsers().then((responce)=>{
//     console.log('responce--->',responce.data);
//     setUserData(responce.data)
//     })
//       }, []);
//   function getAllEmployee() {
//       EmployeeService.getAllEmployee().then(
//           (allEmp) => {
//               setAllEmp(allEmp.data);
//           });
//   }
//   const getData = (data)=>{
// console.log('from App',data)
// setC1Data(data)
//   }
  return (

    <div>
      {/* {console.log('userdata:app',userData)} */}
   {/* <Booklist/> */}
   {/* <BooklistPract/> */}
   {/* <BookList_ref/> */}
   {/* <Parent/> */}
  {/* <CountriesCities/>  */}
  {/* <CitiesCountriesPract/> */}
    {/* <Dropdown/>   */}
   {/* <EnhancedLikes /> 
    <EnhancedComments /> */}
    {/* <Login/> */}
    {/* <SignIn/> */}
    {/* <Routes>
        <Route path="/" element={<Login/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/Signup" element={<Signup/>}/>
        <Route path="/userdetails" element = {<UserDetails/>}/>
      </Routes> */}
    {/* <BrowserRouter> */}
      {/* <NavigationBar/> */}
      {/* <Switch>
        <Route exact path='/login' component={Login}/>
        <Route exact path='/signup' component={Signup}/> */}
      {/* <Route exact path="/" component={Home}/>
      <Route exact path="/home" component={Home}/>
      <Route exact path="/about" render = {()=> <React.Suspense fallback={<span>LOADING...</span>}><AboutComponent/></React.Suspense>}/>
      <Route exact path="/booklist" render = {()=> <Booklist greet='Welcome to'/>}/>
      <Route exact path="/componentCom" component={Parent_content}/>
      <Route exact path="/likes" render = {()=> <EnhancedLikes greet='Welcome to'/>}/>
      <Route exact path="/searchuser/:id" component={SearchUser}/>
      <Route exact path="/userlist" component={UserList}/>
       <Route exact path="/userdetails" render = {()=> <React.Suspense fallback={<span>LOADING...</span>}> <UserDetails usersList={userData}/></React.Suspense> }/> 
      <Route path={'/userlist/userInfo/:id'} component={UserInfo}/>  
      <Route exact path='/lifecycle_methods' component={Parent_component}/> 
      <Route exact path='/*' component={Invalid_route}/> */}

      {/* </Switch>
      </BrowserRouter> */}
      {/* <C1_component C1ToApp={getData}/>
      <C2_component appToC2 = {C1Data}/>  */}
    {/* <ConterControl/>
    <CounterResult/> */}
    {/* <BasicMenu/> */}
  {/* <AllUsers/>  */}
  <hr/>
    {/* <AddUser/>
    <SearchUser/>
    <DeleteUser/> */}
    {/* <FuncBooklist/> */}
    {/* <Conditional_render/> */}
    {/* <Mui_Select/> */}
{/* <MultipleSelect/>
<AddUser/> */}
{/* <Task1/>

 
{/* <ReactHooks/> */}
{/* <Like_Dislike/> */}
{/* <Comp1/> */}
{/* <ReactForms/> */}
{/* <UseReducerHook/> */}
<br/>
{/* <ReactHooks/> */}
<br/>
<UseMemoHook/>
<SwitchMethod/>
<Emnummethod/>
{/* <FormData/>
<ShowHide/>
<Timer/>
<ProgressBarDemo/>
<TwoWayDataBinding/> */}
{/* 
<Composition2/>
<Composition3/> */}
{/* <Inheritance2/>
<Inheritance3/>
<UseErrorBoundary/> */}
{/* <Comp3/> */}
{/* <Controlled/>
<Uncontrolled/> */}
{/* <InterceptorComp/> */}
{/* <ForwardParent/> */}
{/* <Lifecycle_Parent/> */}
{/* <Routes>
  <Route path="/login" element={<Login/>}/>
</Routes> */}
    </div>
  );
}

export default App;
