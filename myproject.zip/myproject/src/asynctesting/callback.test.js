// jest.setTimeout(10000);
function functionCall(callback){
    setTimeout(()=>{
    callback('data')
    },6000) //it wait min 5000 seconds
}
//functionCall(data=>console.log('Data:: ',data))
function getdata(data){
    console.log('Data:: ',data);
}
functionCall(getdata);

describe('Async test suit fro callback function',()=>{
    it.skip('1-should test Async code using callbacks',()=>{
        let result = 'NA'
        function mycallback(data){
            console.log('data',data)
            result = data
            expect(data).toBe('data')
        }
        functionCall(mycallback) //function name should me same ex:functionCall
        expect(result).toBe('data')
    })
    it('2-should test Async code using callbacks',(done)=>{
        let result = 'NA'
        function mycallback(data){
            console.log('data',data)
            try{
            
            result = data
            expect(result).toBe('data')
             done()  //thrown: "Exceeded timeout of 5000 ms for a test.
            } catch(error){
            done(error)
            }
        }
        functionCall(mycallback) //function name should me same ex:functionCall

    })
    
})
