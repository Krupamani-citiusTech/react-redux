function GetPromise(flag){
    return new Promise((resolve,reject)=>{
    setTimeout(()=>{
        if(flag>=5){
         resolve('data')
        } else {
            reject('error')
        }
    },10000)
    
    })
}

describe('test suit for promises',()=>{
    it('1-should execute promise',()=>{
        return GetPromise(6).then(data=>{
            expect(data).toBe('data')
        })
    })
})