import ErrorHandler from "./errorHandler";
export default function City({name}) {
    try {
      return <div>Hello, visit {name.toUpperCase()}</div>
    } catch (error) {
      return <ErrorHandler error={error} />
    }
  }