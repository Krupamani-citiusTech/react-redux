import ErrorHandler from "./errorHandler";
export default function Country({capital}) {
    try {
        {console.log('capital:',capital)}
      return <div>Hello, visit {capital.toUpperCase()}</div>
      
    } catch (error) {
      return <ErrorHandler error={error} />
    }
  }