import City from "./city";
import Country from "./country";

export default function EMain(){
    return (
        <div>
          <Country />
          <City />
        </div>
      )
}