
const Bomb = ()=>{
    throw new Error('💥 CABOOM 💥')
}
export default Bomb;