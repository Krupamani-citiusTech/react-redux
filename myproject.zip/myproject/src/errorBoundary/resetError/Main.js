
import { useState } from "react";
import { ErrorBoundary } from "react-error-boundary";
import Bomb from "./bomb";
import ErrorFallback from "./errorFallback";
const Main = ()=>{
    const [explode, setExplode] = useState(false)
  return (
    <div>
      <button onClick={() => setExplode(e => !e)}>toggle explode</button>
      <ErrorBoundary
        FallbackComponent={ErrorFallback}
        onReset={() => setExplode(false)}
        resetKeys={[explode]}
      >
        {explode ? <Bomb /> : null}
      </ErrorBoundary>
    </div>
  )
}
export default Main;