import React from "react";
import { Button, Grid, TextField} from "@material-ui/core";
import './login.css';
import { Link } from "react-router-dom";
import instance from "../urls";
import { AUTH_TOKEN } from "../state-management/actions/authAction";
import { connect } from "react-redux";
class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email:'',
            password:'',
            authToken:''
        }
    }
    inputHandler = (event)=>{
        const { id, value } = event.target;
        this.setState(prevState => ({
            ...prevState,
            [id]: value
        }));
    }
    handleSubmit = (e)=>{
    const {email,password} = this.state;
   instance.post('/login', {
       email : email,
       password : password
    })
.then(res => {
    console.log(res)
    this.setState({
        authToken : res.data.accessToken
    })
    localStorage.setItem('token', res.data.accessToken);
    this.props.authDispatch(this.state.authToken)
})

   e.preventDefault()
    }
    render() {
        return (
            <div>
                <center>
                <form className="main-container" onSubmit={this.handleSubmit}>
                <Grid container spacing={1}>
                    <Grid item xs={12} md={12}>
                                <TextField fullWidth
                                    variant="outlined"
                                    label="Username"
                                    placeholder="Enter username"
                                    type="email"
                                    value={this.state.email} id="email" onChange={this.inputHandler}
                                />
                            </Grid> 
                    <Grid item xs={12} md={12}>
                    <TextField  fullWidth
                                    variant="outlined"
                                    label="Password"
                                    placeholder="Enter password"
                                    type="password"
                                    value={this.state.password} id="password" onChange={this.inputHandler}
                                />
                    </Grid> 
                    <Grid item xs={12} md={12}>
                    <Button className="signin-btn" variant="contained" type="submit" color="secondary">login</Button>
                    </Grid>
                    <Grid item xs={12} md={12}>
                    <div>Don't have an account? <Link to="/signup">Signup</Link></div>
                    </Grid>  
                          
                </Grid>
                </form>
                {console.log('token from store:',this.props.authTokenVal)}
                </center>
            </div>
        )
    }
}
const mapStateToProps = (stateVal)=>{
    return {
        authTokenVal : stateVal.authRed.authKey
    }
}
const mapDispatchToProps = (dispatch)=>{
    return {
        authDispatch: (authToken) => dispatch({ type: AUTH_TOKEN,payload:authToken }),
    }
}
let hoc = connect(mapStateToProps,mapDispatchToProps)
export default hoc(Login);