let appState = {
    counter:0,
    history:[],
    users:[],
    authKey: ''
}
export default appState;