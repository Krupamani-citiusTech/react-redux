import React from 'react';
import { connect } from 'react-redux';
import * as actionnames from '../actions/counteraction';
import * as actionCreators from '../actions/actionCreators';
class CounterControl extends React.Component{
    constructor(props){
        super(props)
    }
 
    render(){
        console.log('this.props:: ',this.props)
        return(
            <div>
                <p>Counter Control component</p>
                <button onClick={this.props.increment}>Increment</button> &nbsp;&nbsp;&nbsp;
                <button onClick={this.props.decrement}>Decrement</button>
                <div>{this.props.counterVal}</div>
                </div>
        )
    }
}
//The connect() which portiotions of the state to make available via props
const mapStateToProps = (rootReducer) =>{
    console.log('state',rootReducer)
return{
counterVal : rootReducer.cr.counter
}
}


const mapDispatchToProps = (dispatch)=>{
    return {
        // dispatching plain actions
        increment: () => dispatch(actionCreators.Increment()),
        decrement: () => dispatch({ type: 'DECREMENT' }),
      }
}
let hof = connect(mapStateToProps,mapDispatchToProps)
export default hof(CounterControl);