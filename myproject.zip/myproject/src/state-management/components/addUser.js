import React from "react";
import { connect } from 'react-redux';
import * as actionCreators from '../actions/actionCreators'
class AddUser extends React.Component{
    constructor(props){
        super(props);
        this.username = React.createRef();
        this.password = React.createRef();
    }
    // componentDidMount(){
    //     this.props.addUserHandler()
    // }
    handleClick = ()=>{
        let newuser = {
            userName: this.username.current.value,
            password:this.password.current.value
        }
        this.props.addUserHandler(newuser)
    }
    render(){
        return(
            <div>
                <p>
                    Username:
                    <input type="text" ref={this.username}/>
                </p>
                <p>
                    Password:
                    <input type="password" ref={this.password}/>
                </p>
                <button className="btn btn-primary" onClick={this.handleClick}>ADD THIS USER</button>
                </div>
        )
    }

}
const mapStateToProps = (rootReducer) =>{
    console.log('mapStateToProps',rootReducer)
return{
    allUsers : rootReducer.users.users
}
}
const mapDispathToprops = (dispatch)=>{
return{
    addUserHandler:(newuser)=>dispatch(actionCreators.AddUserAsync(newuser))
}
}
//connect says that give me JS object contain properties
//will make those properties available as props
let hof = connect(mapStateToProps,mapDispathToprops)
export default hof(AddUser);
// export default AddUser;
