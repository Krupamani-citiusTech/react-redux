import React from "react";
import { connect } from "react-redux";
import * as actionCreators from '../actions/actionCreators'
class DeleteUser extends React.Component{
    constructor(props){
        super(props);
        this.deleteUser = React.createRef();
    }
    deleteUserVals = ()=>{
        console.log('deleteUser:: ',this.deleteUser.current.value)
        let deleteUserData = this.deleteUser.current.value;
        this.props.delUserHandler(deleteUserData);
    }
    render(){
        return(
            <div>
                 Delete User:&nbsp;&nbsp;
                <input type="text" ref={this.deleteUser}/>
                <button onClick={this.deleteUserVals}>Delete</button>
            </div>
        )
    }
}
const mapStateToProps = (rootReducer) =>{
    console.log('state',rootReducer)
return{
foundUser : rootReducer.users.users
}
}


const mapDispatchToProps = (dispatch)=>{
    return {
        delUserHandler: (deleteUserData) => dispatch(actionCreators.DeleteUserAsync(deleteUserData)),
      }
}

let hof = connect(mapStateToProps,mapDispatchToProps);
export default hof(DeleteUser);

// export default SearchUser;