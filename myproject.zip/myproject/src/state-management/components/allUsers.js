import React from "react";
import { connect } from 'react-redux';
import * as actionCreators from '../actions/actionCreators'
class AllUsers extends React.Component{
    constructor(props){
        super(props);
    }
    componentDidMount(){
        console.log('coming to componentDidMount')
        this.props.getAllUsersHandler()
    }
    render(){
        return(
            <div>
                {(this.props.allUsers.length === 0)?
                <span>No user data found</span>
                :
                <React.Fragment>
                    {this.props.allUsers.map((users)=>{
                        return <span>UserName: {users.userName} &nbsp;&nbsp;&nbsp; Password : {users.password}<hr/></span>
                    })}
                </React.Fragment>
                }
                </div>
        )
    }
}
const mapStateToProps = (rootReducer) =>{
    console.log('state',rootReducer)
return{
allUsers : rootReducer.users.users
}
}
const mapDispathToprops = (dispatch)=>{

return{
    getAllUsersHandler:()=>dispatch(actionCreators.GetAllUsersAsync())
}
}
let hof = connect(mapStateToProps,mapDispathToprops)
export default hof(AllUsers);
