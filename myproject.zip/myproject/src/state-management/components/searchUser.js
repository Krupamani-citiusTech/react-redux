import React from "react";
import { connect } from "react-redux";
import * as actionCreators from '../actions/actionCreators'
class SearchUser extends React.Component{
    constructor(props){
        super(props);
        this.searchVal = React.createRef();
    }
    SearchUSerVals = ()=>{
        console.log('searchVal:: ',this.searchVal.current.value)
        let searchUser = this.searchVal.current.value;
        this.props.searchHandler(searchUser);
    }
    render(){
        return(
            <div>
                Search User:&nbsp;&nbsp;
                <input type="text" ref={this.searchVal}/>
                <button onClick={this.SearchUSerVals}>Search</button>
            </div>
        )
    }
}
const mapStateToProps = (rootReducer) =>{
    console.log('state',rootReducer)
return{
foundUser : rootReducer.users.users
}
}


const mapDispatchToProps = (dispatch)=>{
    return {
        searchHandler: (searchUser) => dispatch(actionCreators.SatrtswithUserAsync(searchUser)),
      }
}

let hof = connect(mapStateToProps,mapDispatchToProps);
export default hof(SearchUser);

// export default SearchUser;