import React from "react"
import { connect } from "react-redux"

class CounterResult extends React.Component{
    constructor(){
        super()
    }
    render(){
        return(
            <div>
                <h4 id="result">{this.props.counterVal}</h4>
            </div>
        )
    }
}

const mapStateToProps = (rootReducer) =>{
    console.log('state',rootReducer)
return{
counterVal : rootReducer.cr.counter
}
}


// const mapDispatchToProps = (dispatch)=>{
//     return {
//         // dispatching plain actions
//         increment: () => dispatch(actionCreators.Increment()),
//         decrement: () => dispatch({ type: 'DECREMENT' }),
//       }
// }
let hof = connect(mapStateToProps,null)
export default hof(CounterResult);