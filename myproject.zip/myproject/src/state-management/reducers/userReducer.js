import appState from "../app-state";
import * as actionnames from '../actions/counteraction'
export function UserReducer(state=appState,action){
    console.log('user Reducer called')
if(action.type === actionnames.ALLUSERS){
return{
    ...state,
    //  users:state.users
    users:action.users
}
}
if(action.type === actionnames.ADDUSERS){
    console.log('user from reducer',action.newuser)
    return{
        ...state,
        //  users:state.users
        users:state.users.concat(action.newuser)
    }
    }
    if(action.type === actionnames.STARTSWITH){
        console.log('user from reducer',action)
        return{
            ...state,
            users:action.users
        }
        }
        if(action.type === actionnames.DELETEUSER){
            console.log('user from reducer',action)
            return{
                ...state,
                users:action.users
            }
            }
return state
}
