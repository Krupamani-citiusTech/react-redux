import appState from "../app-state";
import * as actionnames from '../actions/counteraction'

function counterReducer(state = appState,action){
    console.log('counterReducer called')
if(action.type===actionnames.INCREMENT){
    let counter = state.counter //get current value of the counter
    ++counter;
    return{
        counter:counter
    }
}
 if(action.type===actionnames.DECREMENT){
    let counter = state.counter //get current value of the counter
    --counter;
    return{
        counter:counter
    }
}  

    return state
 


}
export {counterReducer}