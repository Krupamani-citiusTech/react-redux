import appState from "../app-state"
const authReducer = (state=appState,action)=>{
    console.log('auth reducer',action);
if(action.type === 'AUTH_TOKEN'){
return {
    ...state,
    authKey:action.payload
}
} else {
    return state
}
}
export default authReducer;