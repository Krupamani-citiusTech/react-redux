export const INCREMENT = "INCREMENT";
export const DECREMENT = "DECREMENT";
export const ALLUSERS = "ALLUSERS";
export const ADDUSERS = "ADDUSERS";
export const STARTSWITH = "STARTSWITH";
export const DELETEUSER = "DELETEUSER";
