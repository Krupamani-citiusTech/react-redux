import * as actionnames from './counteraction';
import { userService } from '../../service/userService';
export function Increment(){
    console.log('coming to Increment')
    return{type:actionnames.INCREMENT}
}
// export function IncrementAsync(){
//     console.log('coming to IncrementAsync')
//     return function(dispatch){
//      setTimeout(()=>{
//     dispatch(Increment())
//      },1000)
//     }
// }

export function Decrement(){
    return{type:actionnames.DECREMENT}
}
export function GetAllUsersAsync() {
    return (dispatch) => {
        userService.getAllUsers().then((responce) => {
            dispatch({ type: actionnames.ALLUSERS, users: responce.data })
        }, (error) => {
            return
        })
    }

}
export function SatrtswithUserAsync(searchVal) {
    return (dispatch) => {
        userService.startswith(searchVal).then((responce) => {
            console.log('responce from startswith',responce)
            dispatch({ type: actionnames.STARTSWITH, users: responce.data })
        }, (error) => {
            return
        })
    }

}

export function AddUserAsync(user) {
    console.log('user from action creators', user)
    return (dispatch) => {
        userService.addUser(user).then((responce) => {
            console.log('dispatch',responce)
            // dispatch({ type: actionnames.ADDUSERS, newuser: user })
        }, (error) => {
            return console.log('not working')
        })
    }

}
export function DeleteUserAsync(deluser) {
    console.log('user from action creators', deluser)
    return (dispatch) => {
        userService.deleteUser(deluser).then((responce) => {
            console.log('dispatch',responce)
            // dispatch({ type: actionnames.ADDUSERS, newuser: user })
        }, (error) => {
            return console.log('not working');
        })
    }

}