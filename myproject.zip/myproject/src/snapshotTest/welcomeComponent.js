import React from "react";

class WelcomeComeponent extends React.Component{
    render(){
        return(
            <React.Fragment>
                <h3>Welcome Component</h3>
            </React.Fragment>
        )
    }
}
export default WelcomeComeponent;