import HomeComeponent from "./homeComponent"
import renderer from 'react-test-render';
describe('Snapshot Testing',()=>{
    it('Hello Component',()=>{
        const tree = render.create(<HomeComeponent/>).toJSON()
        console.log(tree)
        expect(tree).toMatchSnapshot()
    })
})