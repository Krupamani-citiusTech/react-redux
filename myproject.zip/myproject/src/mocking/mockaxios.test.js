import axios from 'axios'
import svc from './someservice'
jest.mock('axios');

describe('axios test suit',()=>{
    it.skip('should call axios.get call',()=>{
        svc.GetData()
       expect(axios.get).toHaveBeenCalled()
    })
    it.skip('should call axios.get call only once',()=>{
        svc.GetData()
       expect(axios.get).toHaveBeenCalledTimes(1)
    })
    it.skip('should call axios.get call with the url',()=>{
        svc.GetData()
       expect(axios.get).toHaveBeenCalledWith('https://jsonplaceholder.typicode.com/users/1')
    })
    test.skip('should dispaly number of calls',()=>{
        svc.GetData();
        let calls = axios.get.mock.calls.length;
        console.log('calls count: ',calls)
        console.log('First argumrent with the first call : ',axios.get.mock.calls[0][0])
        console.log('First argumrent with the second call : ',axios.get.mock.calls[0][1])
    })
    it('axios call should get the userIfo',()=>{
        // [
        let userinfo =   {
                "id": 1,
                "name": "Leanne Graham",
                "username": "Bret",
                "email": "Sincere@april.biz",
                "address": {
                  "street": "Kulas Light",
                  "suite": "Apt. 556",
                  "city": "Gwenborough",
                  "zipcode": "92998-3874",
                  "geo": {
                    "lat": "-37.3159",
                    "lng": "81.1496"
                  }
                },
                "phone": "1-770-736-8031 x56442",
                "website": "hildegard.org",
                "company": {
                  "name": "Romaguera-Crona",
                  "catchPhrase": "Multi-layered client-server neural-net",
                  "bs": "harness real-time e-markets"
                }
              }
        // ]
        axios.get.mockResolvedValue(userinfo)
        svc.Search(1)
        expect(axios.get).toHaveBeenCalledWith('https://jsonplaceholder.typicode.com/users/1')
        //set the result val
       
        return svc.Search(1).then(result=>{
            expect(result).toBe(userinfo)
        })
    })
})