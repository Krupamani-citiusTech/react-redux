import * as sm from './simplemath';
export function DoAdd(x,y){
return sm.addition(2,3)
}
export function DoSub(x,y){
    return sm.subtraction(2,3)
    }