export function addition(a,b){
return new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve(a+b)
    },1000)
})
}
export function subtraction(a,b){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve(a-b)
        },1000)
    })
    }