import axios from "axios";

class SomeServiceClass{
GetData(){
axios.get('https://jsonplaceholder.typicode.com/users/1')
axios.get('https://jsonplaceholder.typicode.com/users/2')
}
Search(userid){
return axios.get('https://jsonplaceholder.typicode.com/users/1')
}
}

export default new SomeServiceClass();