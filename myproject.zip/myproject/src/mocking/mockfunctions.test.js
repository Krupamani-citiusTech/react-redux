function Log(data,callback){
callback(data)
}
function Print(data,callback){
    callback(data)
}
function Send(data,callback){
    callback(data)
}

function LogData(data){
    console.log('Log Data: ',data)
}
function PrintData(data){
    console.log('Print Data: ',data)
}
function SendData(data){
    console.log('Send Data: ',data)
}

// Log('Hello',LogData);
// Print('Welcome!',PrintData);
// Send('Bye',SendData);

describe('mock dependency Functions',()=>{
    beforeAll(()=>{
        LogData  = jest.fn();
        PrintData = jest.fn();
        SendData = jest.fn();
    })
    it('Log() should call the dependency call back',()=>{
    Log('Hello',LogData);
    expect(LogData).toHaveBeenCalled();
    
    })
    it('Print() should call the dependency call back',()=>{
        Print('Hello',PrintData);
        expect(PrintData).toHaveBeenCalled();
        
        })
        it('Send() should call the dependency call back',()=>{
            Send('Hello',SendData);
            expect(SendData).toHaveBeenCalled();
            
            })
            it('Mock functions should call only once',()=>{
                Log('Hello',LogData);
                Print('Hello',PrintData);
                Send('Hello',SendData);
                console.log('LogData',LogData)
                expect(LogData).toHaveBeenCalled()
                expect(PrintData).toHaveBeenCalled()
                expect(SendData).toHaveBeenCalled()
                
            })
        })