import * as app from './app';
import * as simplemath from './simplemath';
 jest.mock('./simplemath')
describe('moking a module',()=>{
    it('Doadd() should call addition from simplemath',()=>{
        // simplemath.addition(10,20).then(result=>{
            app.DoAdd(20,10)
            expect(simplemath.addition).toHaveBeenCalled()
        // })
    })
    it('Dosub() should call addition from simplemath',()=>{
        // simplemath.addition(10,20).then(result=>{
            app.DoSub(10,30)
            expect(simplemath.subtraction).toHaveBeenCalled()
        // })
    })
    it('add must complete the addition correctly',()=>{
       
            simplemath.addition.mockResolvedValue(30)
            return app.DoAdd(10,20).then((result)=>{
                console.log('result--->',result)
            expect(result).toBe(30)
        })
    })
})

