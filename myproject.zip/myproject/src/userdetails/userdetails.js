import React, { useEffect, useState } from "react";
import instance from "../urls";

// const UserDetails = (props)=>{
//     const [users,setUsers] = useState([]);
//     useEffect(()=>{
//     instance.get('/users').then((responce)=>{
//         console.log('responce data: ',responce.data)
//         setUsers(responce.data)
//     });
//   },[])
class UserDetails extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
       console.log('from props',this.props)
        return(
  
            <div>
                   <table className="table table-bordered">
                         <thead>
                             <tr>
                                 <th scope="col">S.no</th>&nbsp;
                                 <th scope="col">Firstname</th>&nbsp;
                                 <th scope="col">lastname</th>&nbsp;
                                 <th scope="col">email</th>&nbsp;
                                 <th scope="col">PhoneNo</th>
                             </tr>
                         </thead>
                          <tbody>
                             {this.props.usersList.map((data,index) => {
                                 return <tr key={index}>
                                      <td>{data.id}</td>&nbsp;
                                     <td>{data.firstname}</td>&nbsp;
                                     <td>{data.lastname}</td>&nbsp;
                                     <td>{data.email}</td>&nbsp;
                                     <td>{data.phoneNo}</td>&nbsp;
                                 </tr>
                             })}
        
                         </tbody> 
                      </table>
            </div>
        )
    }
}
export default UserDetails;